rootProject.name = "SubMgrProject"
include(":app")
